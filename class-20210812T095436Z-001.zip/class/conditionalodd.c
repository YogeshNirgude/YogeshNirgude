#include<stdio.h>
int main()
{
	int a;
	printf("\n enter any number");
	scanf("%d",&a);
	a%2==0?printf("\n the number is even"):printf("\n the number is odd");
	return 0;
}
