#include<stdio.h>
int main()
{
	float s,d,t;
	printf("\n enter time and distance");
	scanf("%f%f",&t,&d);
	s=(d/t);
	printf("\n the speed is %f",s);
	return 0;
}

