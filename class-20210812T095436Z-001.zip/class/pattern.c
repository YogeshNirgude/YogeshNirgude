#include<stdio.h>
int main()
{
	int i=1;
	
	for(i=1;i<=5;i++)
	{
		
		printf(" * ");
		
		
	}
	printf("\n");
	printf("  ");
	for(i=1;i<=4;i++)
	{
		
		printf(" * ");
	}
	printf("\n");
	printf("   ");
	for(i=1;i<=3;i++)
	{
		
		printf(" * ");
	}
	printf("\n");
	printf("    ");
	for(i=1;i<=2;i++)
	{
		
		printf(" * ");
	}
	printf("\n");
	printf("      ");
	for(i=1;i<=1;i++)
	{
		
		printf(" * ");
	}
	printf("\n");
	
	return 0;
}
