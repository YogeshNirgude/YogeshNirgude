#include<stdio.h>
int main()
{
	int a=100;
	printf("\n a=%d",a);
	printf("\n adress of a=%p",&a);
	printf("\n value of a adress a=%d",*&a);
	return 0;
}
