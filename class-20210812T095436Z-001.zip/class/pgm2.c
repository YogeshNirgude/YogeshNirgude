#include<stdio.h>
int main()
{
	char a,b;
	printf("enter any two value");
	scanf("%c%c",&a,&b);
	printf("values of a=%c \nand b=%c",a,b);









	return 0;
}

