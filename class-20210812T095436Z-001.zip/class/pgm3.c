#include<stdio.h>
int main()
{
	printf("sizeof int %d",sizeof(int));
	printf("sizeof float%d",sizeof(float));
	printf("size of long %d",sizeof(long));
	printf("size of double%d",sizeof(double)); 
	return 0;
}
