#include<stdio.h>
int main()
{
	int a;
	printf("\n enter any number");
	scanf("%d",&a);
	if((a/2)==0)
	{
		printf("\n %d number is even",a);
	}
	else
	{
		printf("\n %d number is odd",a);
	}
	return 0;
}

	
	
