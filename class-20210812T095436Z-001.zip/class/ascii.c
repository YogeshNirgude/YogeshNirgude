#include<stdio.h>
int main()
{
	int i=1;
	//printf("\n enter any number");
	//scanf("%d",&n);
	for(i=1;i<=255;i++)
	{
		printf("\n %c = %d",i,i);
	}
	return 0;
}
