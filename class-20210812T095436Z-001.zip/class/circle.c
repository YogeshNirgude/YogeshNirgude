#include<stdio.h>
int main()
{
	float r,a,p;
	printf("\n enter the value of redious");
	scanf("%f",&r);
	a=3.14*r*r;
	p=2*3.14*r;
	printf("the area of circle is %f and perimeter of circle is %f",a,p);
	return 0;
}

