#include<stdio.h>
int main()
{
 	float at,pt,a,b;
 	printf("\nenter the value of base and height of the traingle");
 	scanf("%f%f",&a,&b);
 	at=0.5*a*b;
 	pt=2*a+b;
 	printf("\n area of Isosceles traingle is %f and periemeter of Isosceles traingle is%f",at,pt);
 	return 0;
 }
