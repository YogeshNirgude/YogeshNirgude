#include<stdio.h>
int main()
{
	int a,l,w;
	printf("enter the length of rectangle\n");
	scanf("%d",&l);
	printf("enter the width of rectangle\n");
	scanf("%d",&w);
	a=l*w;
	printf("the area of rectangle is =%d",a);
	return 0;
}
	
