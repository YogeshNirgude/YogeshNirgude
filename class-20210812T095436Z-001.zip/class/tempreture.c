#include<stdio.h>
int main()
{
	int f,c;
	printf("enter the Fahrenheit ");
	scanf("%d",&f);
	c=(f-32)*5/9;
	printf("the celcious is %d",c);
	return 0;
}
