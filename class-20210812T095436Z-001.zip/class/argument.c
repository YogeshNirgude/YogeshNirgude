#include<stdio.h>
int main()
{
	int c=10;
	printf("\n %d\t%d\t%d\t",c,c++,++c);
	return 0;
}
/*#include<stdio.h>
int main()
{
	int c=10;
	printf("\n %d\t %d\t%d",c,++c,c++);
	return 0;
}*/
