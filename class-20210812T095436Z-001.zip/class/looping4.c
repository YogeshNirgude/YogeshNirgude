# include<stdio.h>
int main ()
{
int i,j;
for(i=1,i=5,i<=5,j<=1;i++,j--)
 {
 printf("%d \t %d \n",i,j);
 }
 }
