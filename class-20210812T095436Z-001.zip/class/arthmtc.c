#include<stdio.h>
int main()
{
	int a,b,add,sub,mul,div;
	printf("\n enter any two number");
	scanf("%d%d",&a,&b);
	add=a+b;
	sub=a-b;
	mul=a*b;
	div=a/b;
	printf("\n add=%d \nsub=%d \nmul=%d \ndiv%d",add,sub,mul,div);
	return 0;
}
	
	
