#include<stdio.h>
int main ()
{
	int a,b;
	printf("\n enter any 2 numbers");
	scanf("%d%d",&a,&b);
	a>b?printf("\n %d is greatest",a):printf("\n %d is gratest",b);
	return 0;
}

